from typing import Tuple, Any

import requests
import json
from requests.structures import CaseInsensitiveDict
import traceback
from colorama import init as colorama_init
from colorama import Fore
from colorama import Style

colorama_init()


# Adresse et port du serveur hébergeant l'API à interroger
adresse = "app-api-licenses"
port = 5009


def test_requete(method: str = 'GET', path: str = '/', data: dict[str, any] = {}) -> str | tuple[str, Any]:
    headers = CaseInsensitiveDict()
    headers['Content-Type'] = 'application/json'
    try:
        if method.upper() == "GET":
            test = requests.get(f'http://{adresse}:{port}{path}')
        elif method.upper() == "DELETE":
            test = requests.delete(f'http://{adresse}:{port}{path}')
        elif method.upper() == "POST":
            test = requests.post(f'http://{adresse}:{port}{path}', headers=headers, data=json.dumps(data))
        elif method.upper() == "PATCH":
            test = requests.patch(f'http://{adresse}:{port}{path}', headers=headers, data=json.dumps(data))
        else:
            return f"Method {method.upper()} not allowed or not implemented\nRetry with one of the following methods:\n\tGET\n\tPOST\n\tPATCH\n\tDELETE"
    except:
        traceback.print_exc()
        return 0, {}
    return test.status_code, {test.text}



# ----- Tests Site -----

def test_site():
    name_site = 'Marseille'

    # POST /site
    t_post = test_requete('POST', '/site', {'name' : name_site})
    if(t_post[0]==200):
        print(f'\n[{Fore.LIGHTGREEN_EX}{t_post[0]}{Style.RESET_ALL}] {t_post[0] == 200} POST /site \'name\' : {name_site}')
    else:
        print(f'\n[{Fore.LIGHTRED_EX}{t_post[0]}{Style.RESET_ALL}] {t_post[0] == 200} POST /site \'name\' : {name_site}')

    # GET /site/findByName
    for name, code in zip([name_site, 'nomintrouvable'],[200, 400]):
        t_get_findByName = test_requete('GET', f'/site/findByName?name={name}')
        if(t_get_findByName[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_get_findByName[0]}{Style.RESET_ALL}] {t_get_findByName[0] == code} GET /site/findByName?name={name} : {t_get_findByName[1]}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_get_findByName[0]}{Style.RESET_ALL}] {t_get_findByName[0] == code} GET /site/findByName?name={name} : {t_get_findByName[1]}')
    

    # Récupération de l'Id de l'objet 
    try:
        site_id = ""
        temp = test_requete('GET', f'/site/findByName?name={name_site}')[1]
        for liste in temp:
            for i in range(len(liste)):
                if liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                    while liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                        site_id += liste[i]
                        i += 1
                    break
    except:
        site_id = 0

    # PATCH /site
    for id, code in zip([site_id,'bob',306], [200, 400, 404]):
        data = {'name' : 'Paris'}
        t_patch = test_requete('PATCH', f'/site/{id}', data)
        if(t_patch[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_patch[0]}{Style.RESET_ALL}] {t_patch[0] == code} PATCH /site/{id}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_patch[0]}{Style.RESET_ALL}] {t_patch[0] == code} PATCH /site/{id}')

    # GET /site
    t_get = test_requete('GET', '/site')
    if(t_get[0]==200):
        print(f'\n[{Fore.LIGHTGREEN_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == 200} GET /site : {t_get[1]}')
    else:
        print(f'\n[{Fore.LIGHTRED_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == 200} GET /site : {t_get[1]}')

    # GET /site/{siteId}
    for id, code in zip([site_id, 'Naz', 666],[200, 400, 404]):
        t_get = test_requete('GET', f'/site/{id}')
        if(t_get[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == code} GET /site/{id} : {t_get[1]}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == code} GET /site/{id} : {t_get[1]}')

    # DELETE /site/{siteId}
    for id, code in zip([site_id,'Naz', 666], [200, 400, 404]):
        t_delete = test_requete('DELETE', f'/site/{id}')
        if(t_delete[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_delete[0]}{Style.RESET_ALL}] {t_delete[0] == code} DELETE /site/{id}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_delete[0]}{Style.RESET_ALL}] {t_delete[0] == code} DELETE /site/{id}')


# ----- Tests Provider -----

def test_provider():
    name_provider = 'KIRBI'

    # POST /provider
    t_post = test_requete('POST', '/provider', {'name' : name_provider})
    if(t_post[0]==200):
        print(f'\n[{Fore.LIGHTGREEN_EX}{t_post[0]}{Style.RESET_ALL}] {t_post[0] == 200} POST /provider \'name\' : {name_provider}')
    else:
        print(f'\n[{Fore.LIGHTRED_EX}{t_post[0]}{Style.RESET_ALL}] {t_post[0] == 200} POST /provider \'name\' : {name_provider}')

    # GET /provider/findByName
    for name, code in zip([name_provider, 'nomintrouvable'],[200, 400]):
        t_get_findByName = test_requete('GET', f'/provider/findByName?name={name}')
        if(t_get_findByName[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_get_findByName[0]}{Style.RESET_ALL}] {t_get_findByName[0] == code} GET /provider/findByName?name={name} : {t_get_findByName[1]}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_get_findByName[0]}{Style.RESET_ALL}] {t_get_findByName[0] == code} GET /provider/findByName?name={name} : {t_get_findByName[1]}')


    # Récupération de l'Id de l'objet 
    try:
        provider_id = ""
        temp = test_requete('GET', f'/provider/findByName?name={name_provider}')[1]
        for liste in temp:
            for i in range(len(liste)):
                if liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                    while liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                        provider_id += liste[i]
                        i += 1
                    break
    except:
        provider_id = 0

    # PATCH /provider
    for id, code in zip([provider_id,'bob',306], [200, 400, 404]):
        t_patch = test_requete('PATCH', f'/provider/{id}', {'name': 'Kirbi Tech'})
        if(t_patch[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_patch[0]}{Style.RESET_ALL}] {t_patch[0] == code} PATCH /provider/{id}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_patch[0]}{Style.RESET_ALL}] {t_patch[0] == code} PATCH /provider/{id}')

    # GET /provider
    t_get = test_requete('GET', '/provider')
    if(t_get[0]==200):
        print(f'\n[{Fore.LIGHTGREEN_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == 200} GET /provider : {t_get[1]}')
    else:
        print(f'\n[{Fore.LIGHTRED_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == 200} GET /provider : {t_get[1]}')

    # GET /provider/{providerId}
    for id, code in zip([provider_id, 'Naz', 666],[200, 400, 404]):
        t_get = test_requete('GET', f'/provider/{id}')
        if(t_get[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == code} GET /provider/{id} : {t_get[1]}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == code} GET /provider/{id} : {t_get[1]}')

    # DELETE /provider/{providerId}
    for id, code in zip([provider_id,'Naz', 666], [200, 400, 404]):
        t_delete = test_requete('DELETE', f'/provider/{id}')
        if(t_delete[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_delete[0]}{Style.RESET_ALL}] {t_delete[0] == code} DELETE /provider/{id}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_delete[0]}{Style.RESET_ALL}] {t_delete[0] == code} DELETE /provider/{id}')


# ----- Tests Product -----

def test_product():
    name_product = 'EpicGames Launcher'

    # POST /product
    data = {'name' : name_product,
            'nb_licenses' : 2000,
            'nb_used_licenses' : 1800,
            'provider_id' : 3,
            'site_id' : 1}
    t_post = test_requete('POST', '/product', data)
    if(t_post[0]==200):
        print(f'\n[{Fore.LIGHTGREEN_EX}{t_post[0]}{Style.RESET_ALL}] {t_post[0] == 200} POST /product \'name\' : {name_product}')
    else:
        print(f'\n[{Fore.LIGHTRED_EX}{t_post[0]}{Style.RESET_ALL}] {t_post[0] == 200} POST /product \'name\' : {name_product}')

    # GET /product/findByName
    t_get_findByName = test_requete('GET', f'/product/findByName?name={name_product}')
    for name, code in zip([name_product, 'nomintrouvable'],[200, 400]):
        t_get_findByName = test_requete('GET', f'/product/findByName?name={name}')
        if(t_get_findByName[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_get_findByName[0]}{Style.RESET_ALL}] {t_get_findByName[0] == code} GET /product/findByName?name={name} : {t_get_findByName[1]}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_get_findByName[0]}{Style.RESET_ALL}] {t_get_findByName[0] == code} GET /product/findByName?name={name} : {t_get_findByName[1]}')

    try:
        product_id = ""
        temp = test_requete('GET', f'/product/findByName?name={name_product}')[1]
        for liste in temp:
            for i in range(len(liste)):
                if liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                    while liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                        product_id += liste[i]
                        i += 1
                    break
    except:
        product_id = 0

    # PATCH /product
    for id, code in zip([product_id,'bob',306], [200, 400, 404]):
        data = {'name': 'Launcher Rockstar Games',
                'nb_licenses' : 0,
                'nb_used_licenses' : 0}
        t_patch = test_requete('PATCH', f'/product/{id}', data)
        if(t_patch[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_patch[0]}{Style.RESET_ALL}] {t_patch[0] == code} PATCH /product/{id}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_patch[0]}{Style.RESET_ALL}] {t_patch[0] == code} PATCH /product/{id}')


    # GET /product
    t_get = test_requete('GET', '/product')
    if(t_get[0]==200):
        print(f'\n[{Fore.LIGHTGREEN_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == 200} GET /product : {t_get[1]}')
    else:
        print(f'\n[{Fore.LIGHTRED_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == 200} GET /product : {t_get[1]}')

    # GET /product/{productId}
    for id, code in zip([product_id, 'Naz', 666],[200, 400, 404]):
        t_get = test_requete('GET', f'/product/{id}')
        if(t_get[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == code} GET /product/{id} : {t_get[1]}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == code} GET /product/{id} : {t_get[1]}')

    # DELETE /product/{productId}
    for id, code in zip([product_id,'Naz', 666], [200, 400, 404]):
        t_delete = test_requete('DELETE', f'/product/{id}')
        if(t_delete[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_delete[0]}{Style.RESET_ALL}] {t_delete[0] == code} DELETE /product/{id}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_delete[0]}{Style.RESET_ALL}] {t_delete[0] == code} DELETE /product/{id}')


# ----- Tests License -----

def test_license():
    key_license = 'AAAAA-BBBBB-CCCCC-11111-22222'

    # POST /license
    data = {'key' : key_license,
            'date_start' : '1999-12-31',
            'date_expuration' : '2004-05-12',
            'is_used' : False, 
            'user_id' : 1,
            'product_id' : 12}
    t_post = test_requete('POST', '/license', data)
    if(t_post[0]==200):
        print(f'\n[{Fore.LIGHTGREEN_EX}{t_post[0]}{Style.RESET_ALL}] {t_post[0] == 200} POST /license {data}')
    else:
        print(f'\n[{Fore.LIGHTRED_EX}{t_post[0]}{Style.RESET_ALL}] {t_post[0] == 200} POST /license {data}')

    # GET /license/findByKey
    t_get_findByKey = test_requete('GET', f'/license/findByKey?key={key_license}')
    for key, code in zip([key_license, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'],[200, 400]):
        t_get_findByName = test_requete('GET', f'/license/findByKey?key={key}')
        if(t_get_findByName[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_get_findByName[0]}{Style.RESET_ALL}] {t_get_findByName[0] == code} GET /license/findByKey?key={key} : {t_get_findByName[1]}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_get_findByName[0]}{Style.RESET_ALL}] {t_get_findByName[0] == code} GET /license/findByKey?key={key} : {t_get_findByName[1]}')

    try:
        license_id = ""
        temp = test_requete('GET', f'/license/findByKey?key={key_license}')[1]
        for liste in temp:
            for i in range(len(liste)):
                if liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                    while liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                        license_id += liste[i]
                        i += 1
                    break
    except:
        license_id = 0

    # PATCH /license
    for id, code in zip([license_id,'bob',306], [200, 400, 404]):
        t_patch = test_requete('PATCH', f'/license/{id}', {'key' : 'ZZZZZ-99999-ZZZZZ-99999-ZZZZZ'})
        if(t_patch[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_patch[0]}{Style.RESET_ALL}] {t_patch[0] == code} PATCH /license/{id}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_patch[0]}{Style.RESET_ALL}] {t_patch[0] == code} PATCH /license/{id}')


    # GET /license/{licenseId}
    t_get = test_requete('GET', f'/license/{license_id}')
    for id, code in zip([license_id, 'Naz', 666],[200, 400, 404]):
        t_get = test_requete('GET', f'/license/{id}')
        if(t_get[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == code} GET /license/{id} : {t_get[1]}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_get[0]}{Style.RESET_ALL}] {t_get[0] == code} GET /license/{id} : {t_get[1]}')

    # GET /license/findByIsUsed
    for boolean, code in zip([True, 'pasunbooleen'],[200, 400]):
        t_get_findByIsUsed = test_requete('GET', f'/license/findByIsUsed?boolean={boolean}')
        if(t_get_findByIsUsed[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_get_findByIsUsed[0]}{Style.RESET_ALL}] {t_get_findByIsUsed[0] == code} GET /license/findByIsUsed?boolean={boolean} : {t_get_findByIsUsed[1]}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_get_findByIsUsed[0]}{Style.RESET_ALL}] {t_get_findByIsUsed[0] == code} GET /license/findByIsUsed?boolean={boolean} : {t_get_findByIsUsed[1]}')

    # GET /license/findByIdUser
    for user_id, code in zip([1, 666],[200, 400]):
        t_get_findByUserId = test_requete('GET', f'/license/findByUserId?user_id={user_id}')
        if(t_get_findByUserId[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_get_findByUserId[0]}{Style.RESET_ALL}] {t_get_findByUserId[0] == code} GET /license/findByUserId?user_id={user_id} : {t_get_findByUserId[1]}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_get_findByUserId[0]}{Style.RESET_ALL}] {t_get_findByUserId[0] == code} GET /license/findByUserId?user_id={user_id} : {t_get_findByUserId[1]}')
    

    # DELETE /license/{licenseId}
    for id, code in zip([license_id, 'Naz', 666],[200, 400, 404]):
        t_delete = test_requete('DELETE', f'/license/{id}')
        if(t_delete[0]==200):
            print(f'\n[{Fore.LIGHTGREEN_EX}{t_delete[0]}{Style.RESET_ALL}] {t_delete[0] == code} DELETE /license/{id}')
        else:
            print(f'\n[{Fore.LIGHTRED_EX}{t_delete[0]}{Style.RESET_ALL}] {t_delete[0] == code} DELETE /license/{id}')


if __name__ == '__main__':
    print("\nTest Site".center(34, '='))
    test_site()
    print("\nTest Provider".center(34, '='))
    test_provider()
    print("\nTest Product".center(34, '='))
    test_product()
    print("\nTest License".center(34, '='))
    test_license()