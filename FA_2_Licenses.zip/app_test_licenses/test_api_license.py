from typing import Tuple, Any

import requests
import json
from requests.structures import CaseInsensitiveDict
import traceback

# Adresse et port du serveur hébergeant l'API à interroger
adresse = "app-api-licenses"
port = 5009


def test_requete(method: str = 'GET', path: str = '/', data: dict[str, any] = {}) -> str | tuple[str, Any]:
    headers = CaseInsensitiveDict()
    headers['Content-Type'] = 'application/json'
    try:
        if method.upper() == "GET":
            test = requests.get(f'http://{adresse}:{port}{path}')
        elif method.upper() == "DELETE":
            test = requests.delete(f'http://{adresse}:{port}{path}')
        elif method.upper() == "POST":
            test = requests.post(f'http://{adresse}:{port}{path}', headers=headers, data=json.dumps(data))
        elif method.upper() == "PATCH":
            test = requests.patch(f'http://{adresse}:{port}{path}', headers=headers, data=json.dumps(data))
        else:
            return f"Method {method.upper()} not allowed or not implemented\nRetry with one of the following methods:\n\tGET\n\tPOST\n\tPATCH\n\tDELETE"
    except:
        traceback.print_exc()
        return 0, {}
    return test.status_code, {test.text}



# ----- Tests Site -----

def test_site():
    name_site = 'Marseille'

    # POST /site
    t_post = test_requete('POST', '/site', {'name' : name_site})
    print(f'POST /site {{data}} : {t_post}')

    # GET /site/findByName
    t_get_findByName = test_requete('GET', f'/site/findByName?name={name_site}')
    print(f'GET /site/findByName?name={name_site} : {t_get_findByName}')
    
    try:
        site_id = ""
        temp = t_get_findByName[1]
        for liste in temp:
            for i in range(len(liste)):
                if liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                    while liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                        site_id += liste[i]
                        i += 1
                    break
    except:
        site_id = 0

    # PATCH /site
    t_patch = test_requete('PATCH', f'/site/{site_id}', {'name' : 'Paris'})
    print(f'PATCH /site/{{siteId}} {{data}} : {t_patch}')

    # GET /site
    t_get = test_requete('GET', '/site')
    print(f'GET /site : {t_get}')

    # GET /site/{siteId}
    t_get = test_requete('GET', f'/site/{site_id}')
    print(f'GET /site/{{siteId}} : {t_get}')

    # DELETE /site/{siteId}
    t_delete = test_requete('DELETE', f'/site/{site_id}')
    print(f'DELETE /site/{{siteId}} : {t_delete}')


# ----- Tests Provider -----

def test_provider():
    name_provider = 'KIRBI'

    # POST /provider
    t_post = test_requete('POST', '/provider', {'name' : name_provider})
    print(f'POST /provider {{data}} : {t_post}')

    # GET /provider/findByName
    t_get_findByName = test_requete('GET', f'/provider/findByName?name={name_provider}')
    print(f'GET /provider/findByName?name={name_provider} : {t_get_findByName}')

    try:
        provider_id = ""
        temp = t_get_findByName[1]
        for liste in temp:
            for i in range(len(liste)):
                if liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                    while liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                        provider_id += liste[i]
                        i += 1
                    break
    except:
        provider_id = 0

    # PATCH /provider
    t_patch = test_requete('PATCH', f'/provider/{provider_id}', {'name': 'Kirbi Tech'})
    print(f'PATCH /provider/{{providerId}} {{data}} : {t_patch}')

    # GET /provider
    t_get = test_requete('GET', '/provider')
    print(f'GET /provider : {t_get}')

    # GET /provider/{providerId}
    t_get = test_requete('GET', f'/provider/{provider_id}')
    print(f'GET /provider/{{providerId}} : {t_get}')

    # DELETE /provider/{providerId}
    t_delete = test_requete('DELETE', f'/provider/{provider_id}')
    print(f'DELETE /provider/{{providerId}} : {t_delete}')


# ----- Tests Product -----

def test_product():
    name_product = 'EpicGames Launcher'

    # POST /product
    t_post = test_requete('POST', '/product', { 'name' : name_product,
                                                'nb_licenses' : 2000,
                                                'nb_used_licenses' : 1800,
                                                'provider_id' : 3,
                                                'site_id' : 1})
    print(f'POST /product {{data}} : {t_post}')

    # GET /product/findByName
    t_get_findByName = test_requete('GET', f'/product/findByName?name={name_product}')
    print(f'GET /product/findByName?name={name_product} : {t_get_findByName}')

    try:
        product_id = ""
        temp = t_get_findByName[1]
        for liste in temp:
            for i in range(len(liste)):
                if liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                    while liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                        product_id += liste[i]
                        i += 1
                    break
    except:
        product_id = 0

    # PATCH /product
    t_patch = test_requete('PATCH', f'/product/{product_id}', {'name': 'Launcher Rockstar Games',
                                                    'nb_licenses' : 0,
                                                    'nb_used_licenses' : 0})
    print(f'PATCH /product/{{productId}} {{data}} : {t_patch}')

    # GET /product
    t_get = test_requete('GET', '/product')
    print(f'GET /product : {t_get}')

    # GET /product/{productId}
    t_get = test_requete('GET', f'/product/{product_id}')
    print(f'GET /product/{{productId}} : {t_get}')

    # DELETE /product/{productId}
    t_delete = test_requete('DELETE', f'/product/{product_id}')
    print(f'DELETE /product/{{productId}} : {t_delete}')


# ----- Tests License -----

def test_license():
    key_license = 'AAAAA-BBBBB-CCCCC-11111-22222'

    # POST /license
    t_post = test_requete('POST', '/license', { 'key' : key_license,
                                                'date_start' : '1999-12-31',
                                                'date_expuration' : '2004-05-12',
                                                'is_used' : False, 
                                                'user_id' : 1,
                                                'product_id' : 12})
    print(f'POST /license {{data}} : {t_post}')

    # GET /license/findByKey
    t_get_findByKey = test_requete('GET', f'/license/findByKey?key={key_license}')
    print(f'GET /license/findByKey?key={key_license} : {t_get_findByKey}')

    try:
        license_id = ""
        temp = t_get_findByKey[1]
        for liste in temp:
            for i in range(len(liste)):
                if liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                    while liste[i] in ['0','1','2','3','4','5','6','7','8','9']:
                        license_id += liste[i]
                        i += 1
                    break
    except:
        license_id = 0

    # PATCH /license
    t_patch = test_requete('PATCH', f'/license/{license_id}', {'key' : 'ZZZZZ-99999-ZZZZZ-99999-ZZZZZ'})
    print(f'PATCH /license/{{licenseId}} {{data}} : {t_patch}')

    # GET /license
    t_get = test_requete('GET', '/license')
    print(f'GET /license : {t_get}')

    # GET /license/{licenseId}
    t_get = test_requete('GET', f'/license/{license_id}')
    print(f'GET /license/{{licenseId}} : {t_get}')

    # GET /license/findByIsUsed
    t_get_findByIsUsed = test_requete('GET', '/license/findByIsUsed?boolean=false')
    print(f'GET /license/findByIsUsed?boolean=false : {t_get_findByIsUsed}')

    # GET /license/findByIdUser
    t_get_findByUserId = test_requete('GET', '/license/findByUserId?user_id=1')
    print(f'GET /license/findByUserId?user_id=1 : {t_get_findByUserId}')
    

    # DELETE /license/{licenseId}
    t_delete = test_requete('DELETE', f'/license/{license_id}')
    print(f'DELETE /license/{{licenseId}} : {t_delete}')


if __name__ == '__main__':
    print("Test Site".center(34, '='))
    test_site()
    print("Test Provider".center(34, '='))
    test_provider()
    print("Test Product".center(34, '='))
    test_product()
    print("Test License".center(34, '='))
    test_license()