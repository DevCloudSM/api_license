from typing import Tuple, Any

import requests
import json
from requests.structures import CaseInsensitiveDict

# Adresse et port du serveur hébergeant l'API à interroger
adresse = "app-api-licenses"
port = 5009


def test_requete(method: str = 'GET', path: str = '/', data: dict[str, str] = {}) -> str | tuple[str, Any]:
    headers = CaseInsensitiveDict()
    headers['Content-Type'] = 'application/json'
    if method.upper() == "GET":
        test = requests.get(f'http://{adresse}:{port}{path}')
    elif method.upper() == "DELETE":
        test = requests.delete(f'http://{adresse}:{port}{path}')
    elif method.upper() == "POST":
        test = requests.post(f'http://{adresse}:{port}{path}', headers=headers, data=json.dumps(data))
        return f'Code {test.status_code}', test.text
    elif method.upper() == "PATCH":
        test = requests.patch(f'http://{adresse}:{port}{path}', headers=headers, data=json.dumps(data))
        return f'Code {test.status_code}', test.text
    else:
        return f"Method {method.upper()} not allowed or not implemented\nRetry with one of the following methods:\n\tGET\n\tPOST\n\tPATCH\n\tDELETE"
    return f'Code {test.status_code}', json.loads(test.text)



# ----- Tests Site -----

def test_site():
    # POST /site
    t_post = test_requete('POST', '/site', {'name' : 'Saint-Nazaire'})
    print(f'POST /site {{data}} : {t_post}')

    # PATCH /site
    t_patch = test_requete('PATCH', '/site/6', {'name' : 'St-Nazaire'})
    print(f'PATCH /site/{{siteId}} {{data}} : {t_patch}')

    # GET /site
    t_get = test_requete('GET', '/site')
    print(f'GET /site : {t_get}')

    # GET /site/{siteId}
    t_get = test_requete('GET', '/site/6')
    print(f'GET /site/{{siteId}} : {t_get}')

    # GET /site/findByName
    t_get_findByName = test_requete('GET', '/site/findByName?name=NAZ')
    print(f'GET /site/findByName?name=NAZ : {t_get_findByName}')

    # DELETE /site/{siteId}
    t_delete = test_requete('DELETE', '/site/2')
    print(f'DELETE /site/{{siteId}} : {t_delete}')


# ----- Tests Provider -----

def test_provider():
    # POST /provider
    t_post = test_requete('POST', '/provider', {'name' : 'KIRBI'})
    print(f'POST /provider {{data}} : {t_post}')

    # PATCH /provider
    t_patch = test_requete('PATCH', '/provider/4', {'name': 'Kirbi Tech'})
    print(f'PATCH /provider/{{providerId}} {{data}} : {t_patch}')

    # GET /provider
    t_get = test_requete('GET', '/provider')
    print(f'GET /provider : {t_get}')

    # GET /provider/{providerId}
    t_get = test_requete('GET', '/provider/4')
    print(f'GET /provider/{{providerId}} : {t_get}')

    # GET /provider/findByName
    t_get_findByName = test_requete('GET', '/provider/findByName?name=K')
    print(f'GET /provider/findByName?name=K : {t_get_findByName}')

    # DELETE /provider/{providerId}
    t_delete = test_requete('DELETE', '/provider/4')
    print(f'DELETE /provider/{{providerId}} : {t_delete}')



# ----- Tests Product -----

def test_product():
    # POST /product
    t_post = test_requete('POST', '/product', {'name' : 'EpicGames Launcher',
                                               'nb_licenses' : 2000,
                                               'nb_used_licenses' : 1800,
                                               'provider_id' : 3,
                                               'site_id' : 1})
    print(f'POST /product {{data}} : {t_post}')

    # PATCH /product
    t_patch = test_requete('PATCH', '/product/14', {'name': 'Launcher EPIC GAMES',
                                                    'nb_licenses' : 0,
                                                    'nb_used_licenses' : 0})
    print(f'PATCH /product/{{productId}} {{data}} : {t_patch}')

    # GET /product
    t_get = test_requete('GET', '/product')
    print(f'GET /product : {t_get}')

    # GET /product/{productId}
    t_get = test_requete('GET', '/product/14')
    print(f'GET /product/{{productId}} : {t_get}')

    # GET /product/findByName
    t_get_findByName = test_requete('GET', '/product/findByName?name=GAMe')
    print(f'GET /product/findByName?name=GAMe : {t_get_findByName}')

    # DELETE /product/{productId}
    t_delete = test_requete('DELETE', '/product/14')
    print(f'DELETE /product/{{productId}} : {t_delete}')


# ----- Tests License -----

def test_license():
    # POST /license
    t_post = test_requete('POST', '/license', { 'key' : 'AAAAA-BBBBB-CCCCC-11111-22222',
                                                'date_start' : '1999-12-31',
                                                'date_expuration' : '2004-05-12',
                                                'is_used' : False, 
                                                'user_id' : 1,
                                                'product_id' : 12})
    print(f'POST /license {{data}} : {t_post}')

    # PATCH /license
    t_patch = test_requete('PATCH', '/license/30', {'key' : 'ZZZZZ-99999-ZZZZZ-99999-ZZZZZ'})
    print(f'PATCH /license/{{licenseId}} {{data}} : {t_patch}')

    # GET /license
    t_get = test_requete('GET', '/license')
    print(f'GET /license : {t_get}')

    # GET /license/{licenseId}
    t_get = test_requete('GET', '/license/30')
    print(f'GET /license/{{licenseId}} : {t_get}')

    # GET /license/findByKey
    t_get_findByKey = test_requete('GET', '/license/findByKey?key=999')
    print(f'GET /license/findByKey?key=999 : {t_get_findByKey}')

    # GET /license/findByIsUsed
    t_get_findByIsUsed = test_requete('GET', '/license/findByIsUsed?boolean=false')
    print(f'GET /license/findByIsUsed?boolean=false : {t_get_findByIsUsed}')

    # GET /license/findByIdUser
    t_get_findByUserId = test_requete('GET', '/license/findByUserId?user_id=1')
    print(f'GET /license/findByUserId?user_id=1 : {t_get_findByUserId}')
    

    # DELETE /license/{licenseId}
    t_delete = test_requete('DELETE', '/license/30')
    print(f'DELETE /license/{{licenseId}} : {t_delete}')


if __name__ == '__main__':
    print("Test Site".center(34, '='))
    #test_site()
    print("Test Provider".center(34, '='))
    #test_provider()
    print("Test Product".center(34, '='))
    test_product()
    print("Test License".center(34, '='))
    #test_license()