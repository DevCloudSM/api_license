from flask import Flask, render_template, request, jsonify, Response
import json
import requests
import python_sql as ps

api_license = Flask(__name__)

nom_db = 'licenses'


# Endpoints spécifiques à l'interface utilisateur


@api_license.route('/', endpoint='page_accueil')
def index():
    """site_id = request.args.get("site") if request.args.get("site") else 0
    cles_site = ['id','name']
    cles_provider = ['id','name']
    cles_product = ['id','name', 'nb_licenses', 'nb_used_licenses', 'provider_id', 'site_id']
    sites = ps.get(f'{nom_db}', ['sites'])
    sites = [{key:value for key,value in zip(cles_site, site)} for site in sites]
    # Créer dico en fonction des provider et product présents par site etc


    contenu_site = ps.get(f'{nom_db}', ['provider'], 'parent_id',group_id)
    contenu_site = [{key:value for key,value in zip(cles_groupe, cont)} for cont in contenu_groupe]
    contenu_subnet = ps.get('ipam',['subnet'], 'group_id',group_id)
    contenu_subnet = [{key:value for key,value in zip(cles_subnet, cont)} for cont in contenu_subnet]
    return render_template('ipam.html', tree=groupes, groupes=contenu_groupe, subnets=contenu_subnet)"""


# Endpoints des objets Site


@api_license.route('/site', methods=['GET', 'POST'])
def site():
    if request.method == 'POST':                                # si la méthode est POST
        try:
            site_fields = request.get_json()
            test = ps.post(f'{nom_db}', 'site', {key:value for key,value in site_fields.items()})
            return ("",200) if test else ("", 422)
        except:
            return ("", 422)
    elif request.method == 'GET':                               # si la méthode est GET
        try:
            result = ps.get(f'{nom_db}', ['site'])
            return (jsonify(result), 200)
        except:
            return ("", 400)


@api_license.route('/site/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findSiteById(id: int) -> tuple[str, int]:
    try:
        id = int(id)
    except:
        return ("", 400)
    sites = ps.get(f'{nom_db}', ["site"])
    if id not in [site[0] for site in sites]:
        return ("", 404)
    if request.method == 'GET':
        result = ps.get(f'{nom_db}', ["site"], "id", "=", id)
        return jsonify(result), 200
    if request.method == 'DELETE':
        result = ps.delete(f'{nom_db}', 'site', id)
    if request.method == 'PATCH':
        try:
            site_fields = request.get_json()
            result = ps.patch(f'{nom_db}', 'site', id, {key:value for key,value in site_fields.items()})
        except:
            return ("", 422)
    return ("", 200) if result else ("", 400)


@api_license.route('/site/findByName', methods=['GET'])
def findSiteByName():
        result = ps.get(f'{nom_db}', ["site"], "name", "ILIKE", "%"+request.args.get('name')+"%")
        return (jsonify(result), 200) if result else ("", 400)


# Endpoints des objets Provider


@api_license.route('/provider', methods=['GET', 'POST'])
def provider():
    if request.method == 'POST':                                # si la méthode est POST
        try:
            provider_fields = request.get_json()
            test = ps.post(f'{nom_db}', 'provider', {key:value for key,value in provider_fields.items()})
            return ("",200) if test else ("", 422)
        except:
            return ("", 422)
    elif request.method == 'GET':                               # si la méthode est GET
        try:
            result = ps.get(f'{nom_db}', ['provider'])
            return (jsonify(result), 200)
        except:
            return ("", 400)


@api_license.route('/provider/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findProviderById(id):
    try:
        id = int(id)
    except:
        return ("", 400)
    providers = ps.get(f'{nom_db}', ["provider"])
    if id not in [provider[0] for provider in providers]:
        return ("", 404)
    if request.method == 'GET':
        result = ps.get(f'{nom_db}', ["provider"], "id", "=", id)
        return jsonify(result), 200
    if request.method == 'DELETE':
        result = ps.delete(f'{nom_db}', 'provider', id)
    if request.method == 'PATCH':
        try:
            provider_fields = request.get_json()
            result = ps.patch(f'{nom_db}', 'provider', id, {key:value for key,value in provider_fields.items()})
        except:
            return ("", 422)
    return ("", 200) if result else ("", 400)


@api_license.route('/provider/findByName', methods=['GET'])
def findProviderByName():
    result = ps.get(f'{nom_db}', ["provider"], "name", "ILIKE", "%"+request.args.get('name')+"%")
    return (jsonify(result), 200) if result else ("", 400)


# Endpoints des objets Product


@api_license.route('/product', methods=['GET', 'POST'])
def product():
    if request.method == 'POST':                                # si la méthode est POST
        try:
            product_fields = request.get_json()
            test = ps.post(f'{nom_db}', 'product', {key:value for key,value in product_fields.items()})
            return ("",200) if test else ("", 422)
        except:
            return ("", 422)
    elif request.method == 'GET':                               # si la méthode est GET
        try:
            result = ps.get(f'{nom_db}', ['product'])
            return (jsonify(result), 200)
        except:
            return ("", 400)


@api_license.route('/product/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findProductById(id):
    try:
        id = int(id)
    except:
        return ("", 400)
    products = ps.get(f'{nom_db}', ["product"])
    if id not in [product[0] for product in products]:
        return ("", 404)
    if request.method == 'GET':
        result = ps.get(f'{nom_db}', ['product'], 'id', '=', id)
        return jsonify(result), 200
    if request.method == 'DELETE':
        result = ps.delete(f'{nom_db}', 'product', id)
    if request.method == 'PATCH':
        try:
            product_fields = request.get_json()
            result = ps.patch(f'{nom_db}', 'product', id, {key:value for key,value in product_fields.items()})
        except:
            return ("", 422)
    return ("", 200) if result else ("", 400)


@api_license.route('/product/findByName', methods=['GET'])
def findProductByName():
    result = ps.get(f'{nom_db}', ['product'], 'name', 'ILIKE', '%'+request.args.get('name')+'%')
    return (jsonify(result), 200) if result else ("", 400)


# Endpoints des objets Licenses


@api_license.route('/license', methods=['GET', 'POST'])
def license():
    if request.method == 'POST':                                # si la méthode est POST
        try:
            license_fields = request.get_json()
            test = ps.post(f'{nom_db}', 'license', {key:value for key,value in license_fields.items()})
            return ("",200) if test else ("", 422)
        except:
            return ("", 422)
    elif request.method == 'GET':                               # si la méthode est GET
        try:
            result = ps.get(f'{nom_db}', ["license"])
            return (jsonify(result), 200)
        except:
            return ("", 400)


@api_license.route('/license/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findLicenseById(id):
    try:
        id = int(id)
    except:
        return ("", 400)
    licenses = ps.get(f'{nom_db}', ["license"])
    if id not in [license[0] for license in licenses]:
        return ("", 404)
    if request.method == 'GET':
        result = ps.get(f'{nom_db}', ["license"], "id", "=", id)
        return jsonify(result), 200
    if request.method == 'DELETE':
        result = ps.delete(f'{nom_db}', 'license', id)
    if request.method == 'PATCH':
        try:
            license_fields = request.get_json()
            result = ps.patch(f'{nom_db}', 'license', id, {key:value for key,value in license_fields.items()})
        except:
            return ("", 422)
    return ("", 200) if result else ("", 400)


@api_license.route('/license/findByKey', methods=['GET'])
def findLicenseByKey():
    result = ps.get(f'{nom_db}', ["license"], "key", "ILIKE", "%"+request.args.get('key')+"%")
    return (jsonify(result), 200) if result else ("", 400)


@api_license.route('/license/findByIsUsed', methods=['GET'])
def findLicenseByIsUsed():
    boolean = request.args.get('boolean').lower()
    if boolean not in ['true', 'false']:
        return ("", 400)
    result = ps.get(f'{nom_db}', ["license"], "is_used", "=", boolean)
    return (jsonify(result), 200) if result else ("", 400)


@api_license.route('/license/findByUserId', methods=['GET'])
def findLicenseByUserId():
    result = ps.get(f'{nom_db}', ["license"], "user_id", "=", request.args.get('user_id'))
    return (jsonify(result), 200) if result else ("", 400)


if __name__ == '__main__':
    api_license.run(host='0.0.0.0', port=5009)