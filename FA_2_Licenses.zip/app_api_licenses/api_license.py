from flask import Flask, render_template, request, jsonify, Response, redirect
import json
import requests
import python_sql as ps

api_license = Flask(__name__)

nom_db = 'licenses'


# Endpoints spécifiques à l'interface utilisateur

@api_license.route('/', endpoint='page_accueil')
def index():
    """
    Render the index HTML page.

    :return: The index HTML page.
    :rtype: str
    """
    return render_template("index_licenses.j2")


# Endpoints des objets Site


@api_license.route('/site', methods=['GET', 'POST'])
def site():
    if request.method == 'POST':                                # si la méthode est POST
        try:
            site_fields = request.get_json()
            test = ps.post(f'{nom_db}', 'site', {key:value for key,value in site_fields.items()})
            return ("",200) if test else ("", 422)
        except:
            return ("", 422)
    elif request.method == 'GET':                               # si la méthode est GET
        try:
            result = ps.get(f'{nom_db}', ['site'])
            return (jsonify(result), 200)
        except:
            return ("", 400)


@api_license.route('/site/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findSiteById(id: int) -> tuple[str, int]:
    try:
        id = int(id)
    except:
        return ("", 400)
    sites = ps.get(f'{nom_db}', ["site"])
    if id not in [site[0] for site in sites]:
        return ("", 404)
    if request.method == 'GET':
        result = ps.get(f'{nom_db}', ["site"], "id", "=", id)
        return jsonify(result), 200
    if request.method == 'DELETE':
        result = ps.delete(f'{nom_db}', 'site', id)
    if request.method == 'PATCH':
        try:
            site_fields = request.get_json()
            result = ps.patch(f'{nom_db}', 'site', id, {key:value for key,value in site_fields.items()})
        except:
            return ("", 422)
    return ("", 200) if result else ("", 400)


@api_license.route('/site/findByName', methods=['GET'])
def findSiteByName():
        result = ps.get(f'{nom_db}', ["site"], "name", "ILIKE", "%"+request.args.get('name')+"%")
        return (jsonify(result), 200) if result else ("", 400)


# Endpoints des objets Provider


@api_license.route('/provider', methods=['GET', 'POST'])
def provider():
    if request.method == 'POST':                                # si la méthode est POST
        try:
            provider_fields = request.get_json()
            test = ps.post(f'{nom_db}', 'provider', {key:value for key,value in provider_fields.items()})
            return ("",200) if test else ("", 422)
        except:
            return ("", 422)
    elif request.method == 'GET':                               # si la méthode est GET
        try:
            result = ps.get(f'{nom_db}', ['provider'])
            return (jsonify(result), 200)
        except:
            return ("", 400)


@api_license.route('/provider/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findProviderById(id):
    try:
        id = int(id)
    except:
        return ("", 400)
    providers = ps.get(f'{nom_db}', ["provider"])
    if id not in [provider[0] for provider in providers]:
        return ("", 404)
    if request.method == 'GET':
        result = ps.get(f'{nom_db}', ["provider"], "id", "=", id)
        return jsonify(result), 200
    if request.method == 'DELETE':
        result = ps.delete(f'{nom_db}', 'provider', id)
    if request.method == 'PATCH':
        try:
            provider_fields = request.get_json()
            result = ps.patch(f'{nom_db}', 'provider', id, {key:value for key,value in provider_fields.items()})
        except:
            return ("", 422)
    return ("", 200) if result else ("", 400)


@api_license.route('/provider/findByName', methods=['GET'])
def findProviderByName():
    result = ps.get(f'{nom_db}', ["provider"], "name", "ILIKE", "%"+request.args.get('name')+"%")
    return (jsonify(result), 200) if result else ("", 400)


# Endpoints des objets Product


@api_license.route('/product', methods=['GET', 'POST'])
def product():
    if request.method == 'POST':                                # si la méthode est POST
        try:
            product_fields = request.get_json()
            test = ps.post(f'{nom_db}', 'product', {key:value for key,value in product_fields.items()})
            return ("",200) if test else ("", 422)
        except:
            return ("", 422)
    elif request.method == 'GET':                               # si la méthode est GET
        try:
            result = ps.get(f'{nom_db}', ['product'])
            return (jsonify(result), 200)
        except:
            return ("", 400)


@api_license.route('/product/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findProductById(id):
    try:
        id = int(id)
    except:
        return ("", 400)
    products = ps.get(f'{nom_db}', ["product"])
    if id not in [product[0] for product in products]:
        return ("", 404)
    if request.method == 'GET':
        result = ps.get(f'{nom_db}', ['product'], 'id', '=', id)
        return jsonify(result), 200
    if request.method == 'DELETE':
        result = ps.delete(f'{nom_db}', 'product', id)
    if request.method == 'PATCH':
        try:
            product_fields = request.get_json()
            result = ps.patch(f'{nom_db}', 'product', id, {key:value for key,value in product_fields.items()})
        except:
            return ("", 422)
    return ("", 200) if result else ("", 400)


@api_license.route('/product/findByName', methods=['GET'])
def findProductByName():
    result = ps.get(f'{nom_db}', ['product'], 'name', 'ILIKE', '%'+request.args.get('name')+'%')
    return (jsonify(result), 200) if result else ("", 400)


# Endpoints des objets Licenses


@api_license.route('/license', methods=['GET', 'POST'])
def license():
    if request.method == 'POST':                                # si la méthode est POST
        try:
            license_fields = request.get_json()
            test = ps.post(f'{nom_db}', 'license', {key:value for key,value in license_fields.items()})
            return ("",200) if test else ("", 422)
        except:
            return ("", 422)
    elif request.method == 'GET':                               # si la méthode est GET
        try:
            result = ps.get(f'{nom_db}', ["license"])
            return (jsonify(result), 200)
        except:
            return ("", 400)


@api_license.route('/license/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findLicenseById(id):
    try:
        id = int(id)
    except:
        return ("", 400)
    licenses = ps.get(f'{nom_db}', ["license"])
    if id not in [license[0] for license in licenses]:
        return ("", 404)
    if request.method == 'GET':
        result = ps.get(f'{nom_db}', ["license"], "id", "=", id)
        return jsonify(result), 200
    if request.method == 'DELETE':
        result = ps.delete(f'{nom_db}', 'license', id)
    if request.method == 'PATCH':
        try:
            license_fields = request.get_json()
            result = ps.patch(f'{nom_db}', 'license', id, {key:value for key,value in license_fields.items()})
        except:
            return ("", 422)
    return ("", 200) if result else ("", 400)


@api_license.route('/license/findByKey', methods=['GET'])
def findLicenseByKey():
    result = ps.get(f'{nom_db}', ["license"], "key", "ILIKE", "%"+request.args.get('key')+"%")
    return (jsonify(result), 200) if result else ("", 400)


@api_license.route('/license/findByIsUsed', methods=['GET'])
def findLicenseByIsUsed():
    boolean = request.args.get('boolean').lower()
    if boolean not in ['true', 'false']:
        return ("", 400)
    result = ps.get(f'{nom_db}', ["license"], "is_used", "=", boolean)
    return (jsonify(result), 200) if result else ("", 400)


@api_license.route('/license/findByUserId', methods=['GET'])
def findLicenseByUserId():
    result = ps.get(f'{nom_db}', ["license"], "user_id", "=", request.args.get('user_id'))
    return (jsonify(result), 200) if result else ("", 400)

# Endpoints divers 

@api_license.route("/app", methods=['GET'])
def menu(): 
    site_id = int(request.args.get("site")) if request.args.get("site") else 0
    provider_id = int(request.args.get("provider")) if request.args.get("provider") else 0
    cles_site = ['id','name']
    cles_provider = ['id','name']
    cles_product = ['id','name','nb_licenses','nb_used_licenses','provider_id','site_id']
    cles_license = ['id', 'key', 'date_start', 'date_expiration', 'is_used', 'user_id', 'product_id']
    sites = ps.get(f'{nom_db}', ['site'])
    sites = [{key:value for key,value in zip(cles_site, site)} for site in sites]
    providers = ps.get(f'{nom_db}', ['provider'])
    providers = [{key:value for key,value in zip(cles_provider, provider)} for provider in providers]
    products = ps.get(f'{nom_db}', ['product'])
    products = [{key:value for key,value in zip(cles_product, product)} for product in products]
    dico_arbo = {}
    for i in range (len(products)):
        if products[i]['site_id'] in dico_arbo.keys():
            if products[i]['provider_id'] not in dico_arbo[products[i]['site_id']]:
                dico_arbo[products[i]['site_id']].append(products[i]['provider_id'])
        else:
            dico_arbo[products[i]['site_id']] = [products[i]['provider_id']]

    for key, value in dico_arbo.items():
        for i in range(len(value)):
            for j in range(len(providers)):
                if providers[j]['id']==value[i]:
                    value[i] = {'id' : providers[j]['id'], 'name' : providers[j]['name']}
                    break

    if site_id!=0 and provider_id!=0:
        contenu_product = []
        for i in range (len(products)):
            if products[i]['site_id'] == site_id and products[i]['provider_id'] == provider_id:
                    contenu_product.append(products[i])
                    temp_license = (ps.get(f'{nom_db}',['license'], 'product_id', '=', contenu_product[-1]['id']))
    else:
        contenu_product = ps.get(f'{nom_db}',['product'], 'site_id', '=', site_id)
        contenu_product = [{key:value for key,value in zip(cles_product, cont)} for cont in contenu_product]
        temp_license = []

    if temp_license != []:
        contenu_license = [{key:value for key,value in zip(cles_license, license)} for license in temp_license]
    else:
        contenu_license = []
    
    return render_template('license.html', tree_site=sites, tree_provider=providers, dico=dico_arbo, list_products=contenu_product, list_licenses=contenu_license)


@api_license.route('/edit/site', methods = ['GET'])
def edit_site():
    cles_site = ['id','name']
    id = request.args.get("id")
    site = ps.get(f'{nom_db}',['site'], 'id', '=', id)
    site = {key:value for key,value in zip(cles_site, site[0])}
    print(site)
    return render_template('edit_site.html', site=site)


@api_license.route('/edit/provider', methods = ['GET'])
def edit_provider():
    cles_provider = ['id','name']
    id = request.args.get("id")
    provider = ps.get(f'{nom_db}',['provider'], 'id', '=', id)
    provider = {key:value for key,value in zip(cles_provider, provider[0])}
    return render_template('edit_provider.html', provider=provider)


@api_license.route('/edit/product', methods = ['GET'])
def edit_product():
    cles_product = ['id','name','nb_licenses','nb_used_licenses','provider_id','site_id']
    id = request.args.get("id")
    product = ps.get(f'{nom_db}',['product'], 'id', '=', id)
    product = {key:value for key,value in zip(cles_product, product[0])}
    return render_template('edit_product.html', product=product)


@api_license.route('/edit/license', methods = ['GET'])
def edit_licence():
    cles_licence = ['id', 'key', 'date_start', 'date_expiration', 'is_used', 'user_id', 'product_id']
    id = request.args.get("id")
    license = ps.get(f'{nom_db}',['license'], 'id', '=', id)
    license = {key:value for key,value in zip(cles_licence, license[0])}
    return render_template('edit_license.html', license=license)


@api_license.route('/new/site/', methods = ['GET'])
def new_site():
    cles_site = ['id','name']
    sites = ps.get(f'{nom_db}',['site'])
    sites = [{key:value for key,value in zip(cles_site, site)} for groupe in sites]
    return render_template('new_site.html', sites=sites)


@api_license.route('/new/provider/', methods = ['GET'])
def new_provider():
    cles_provider = ['id','name']
    providers = ps.get(f'{nom_db}',['provider'])
    providers = [{key:value for key,value in zip(cles_provider, provider)} for provider in providers]
    return render_template('new_provider.html', providers=providers)


@api_license.route('/new/product/', methods = ['GET'])
def new_product():
    cles_product = ['id','name','nb_licenses','nb_used_licenses','provider_id','site_id']
    products = ps.get(f'{nom_db}',['product'])
    products = [{key:value for key,value in zip(cles_product, product)} for product in products]
    return render_template('new_product.html', products=products)


@api_license.route('/new/provider/', methods = ['GET'])
def new_licence():
    cles_licence = ['key', 'date_start', 'date_expiration', 'is_used', 'user_id', 'product_id']
    licences = ps.get(f'{nom_db}',['site'])
    licences = [{key:value for key,value in zip(cles_licence, license)} for license in licences]
    return render_template('new_provider.html', licences=licences)


@api_license.route('/action_form/site/<int:id>', methods = ['POST'])
def action_form_site(id:int):
    if id == 0:
        id = request.form.get('id')
    arguments = {
        'name': request.form.get('name')
    }
    ps.patch(f'{nom_db}','site', id, arguments)
    return redirect('/app')


@api_license.route('/action_form/provider/<int:id>', methods=['POST'])
def action_form_provider(id: int):
    if id == 0:
        id = request.form.get('id')
    arguments = {
        'name': request.form.get('name')
    }
    ps.patch(f'{nom_db}','provider', id, arguments)
    return redirect('/app')


@api_license.route('/action_form/product/<int:id>', methods=['POST'])
def action_form_product(id: int):
    if id == 0:
        id = request.form.get('id')
    arguments = {
        'name': request.form.get('name'),
        'nb_licenses': request.form.get('nb_licenses'),
        'nb_used_licenses': request.form.get('nb_used_licenses'),
        'provider_id': request.form.get('provider_id'),
        'site_id': request.form.get('site_id')
    }
    ps.patch(f'{nom_db}','product', id, arguments)
    return redirect('/app')


@api_license.route('/action_form/license/<int:id>', methods=['POST'])
def action_form_license(id: int):
    print(id)
    if id == 0:
        id = request.form.get('id')
    arguments = {
        'key': request.form.get('key'),
        'date_start': request.form.get('date_start'),
        'date_expiration': request.form.get('date_expiration'),
        'is_used': request.form.get('is_used'),
        'user_id': request.form.get('user_id'),
        'product_id': request.form.get('product_id')
    }
    ps.patch(f'{nom_db}','license', id, arguments)
    return redirect('/app')


@api_license.route('/delete/site')
def delete_site():
    id = request.args.get('id')
    ps.delete(f'{nom_db}', 'site', id)
    return redirect('/app')


@api_license.route('/delete/provider')
def delete_provider():
    id = request.args.get('id')
    ps.delete(f'{nom_db}', 'provider', id)
    return redirect('/app')


@api_license.route('/delete/product')
def delete_product():
    id = request.args.get('id')
    ps.delete(f'{nom_db}', 'product', id)
    return redirect('/app')


@api_license.route('/delete/license')
def delete_license():
    id = request.args.get('id')
    ps.delete(f'{nom_db}', 'license', id)
    return redirect('/app')


if __name__ == '__main__':
    api_license.run(host='0.0.0.0', port=5009)